package ex_Interfaces.Interfaces;

public interface AreaCalculavel {
    double calculaArea ();
}
