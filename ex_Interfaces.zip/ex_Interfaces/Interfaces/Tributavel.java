package ex_Interfaces.Interfaces;

public interface Tributavel {
    double calculaTributos ();
}
