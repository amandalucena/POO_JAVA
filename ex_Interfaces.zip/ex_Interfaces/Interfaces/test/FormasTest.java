package ex_Interfaces.Interfaces.test;

import ex_Interfaces.Interfaces.AreaCalculavel;
import ex_Interfaces.Interfaces.dominio.Circulo;
import ex_Interfaces.Interfaces.dominio.Quadrado;
import ex_Interfaces.Interfaces.dominio.Retangulo;

public class FormasTest {
    public static void main(String[] args) {
        AreaCalculavel[] formas = new AreaCalculavel[5];

        formas[0] = new Quadrado(5.0);
        formas[1] = new Retangulo(3.0, 2.0);
        formas[2] = new Circulo(3.0);
        formas[3] = new Retangulo(7.0, 8.0);
        formas[4] = new Circulo(12.0);

        for (int i = 0; i <= formas.length - 1; i++) {
            String nomeForma = formas[i].getClass().getSimpleName();
            System.out.format("Forma: %s, Área: %f/n", nomeForma, formas[i].calculaArea());


        }
    }
}
