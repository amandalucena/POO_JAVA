package ex_Interfaces.Interfaces.test;

import ex_Interfaces.Interfaces.Tributavel;
import ex_Interfaces.Interfaces.dominio.Conta;
import ex_Interfaces.Interfaces.dominio.ContaCorrente;
import ex_Interfaces.Interfaces.dominio.ContaPoupanca;
import ex_Interfaces.Interfaces.dominio.SeguroVida;

import java.util.ArrayList;

public class TributavelTest {
    public static ArrayList <Conta> contas = new ArrayList ();

    public static void main(String[] args) {
        double saldoContaCorrente = 30;
        double saldoContaPoupanca = 4500.89;
        ContaCorrente contaCorrente = new ContaCorrente(saldoContaCorrente);
        ContaPoupanca contaPoupanca = new ContaPoupanca(saldoContaPoupanca);
        SeguroVida seguroVida = new SeguroVida();
        contas.add(contaCorrente);
        contas.add (contaPoupanca);

        for (Conta conta : contas){
            System.out.print("\nTipo: " + conta.getClass().getSimpleName());
            System.out.print("\nSaldo: " + conta.obterSaldo());
            if (conta instanceof Tributavel){
                System.out.print("Tributos: " +((Tributavel) conta).calculaTributos());
            }
        }

    }
}
