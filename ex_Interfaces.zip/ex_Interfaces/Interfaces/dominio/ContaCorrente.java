package ex_Interfaces.Interfaces.dominio;

import ex_Interfaces.Interfaces.Tributavel;

public class ContaCorrente extends Conta implements Tributavel {
    public ContaCorrente (double saldoInicial) {
        super();
        setSaldo(saldoInicial);
    }
        @Override
        public double calculaTributos () {
            return getSaldo() / 100;
        }

        @Override
        public double obterSaldo (){
            return getSaldo();
        }
}
