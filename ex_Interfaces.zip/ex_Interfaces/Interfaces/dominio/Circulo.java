package ex_Interfaces.Interfaces.dominio;

import ex_Interfaces.Interfaces.AreaCalculavel;

public class Circulo implements AreaCalculavel {
    private double raio;

    public Circulo (double raio){
        this.raio = raio;
    }

    public double getRaio() {
        return raio;
    }

    public void setRaio(double raio) {
        this.raio = raio;
    }

    @Override
    public double calculaArea (){
        return 3.14 * Math.pow(raio, 2);
    }
}
