package ex_Interfaces.Interfaces.dominio;

public class ContaPoupanca extends Conta{
    public ContaPoupanca (double saldoInicial){
        super ();
        setSaldo(saldoInicial);
    }

    @Override
    public double obterSaldo (){
        return getSaldo();
    }
}
