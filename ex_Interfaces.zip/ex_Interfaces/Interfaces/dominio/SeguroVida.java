package ex_Interfaces.Interfaces.dominio;

import ex_Interfaces.Interfaces.Tributavel;

public class SeguroVida implements Tributavel {
    @Override
    public double calculaTributos() {
        return 42;
    }
}
