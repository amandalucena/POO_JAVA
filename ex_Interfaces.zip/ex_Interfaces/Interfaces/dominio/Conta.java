package ex_Interfaces.Interfaces.dominio;

public abstract class Conta {
    private double saldo;

    public Conta (){
        this.saldo = 0.0;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public double sacar (double valor) {
        return this.saldo - valor;
    }
    public double depositar (double valor) {
        return this.saldo + valor;
    }
    public abstract double obterSaldo ();
}
